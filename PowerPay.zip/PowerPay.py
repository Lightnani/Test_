def PowerPay():
    """ Electricity cost calculation program based on power and usage time """

    def baseElec():
        """ Calculate base electricity cost """

        print("     Electricity cost")

        watt = int(input("Enter power (Watts): "))
        time = int(input("Enter time (hours): "))
        units = ( watt * time ) / 1000
        calcUnits = units
        baseFee = 0

        rates = [
            (15, 35.23),
            (10, 29.88),
            (10, 32.41),
            (65, 235.54),
            (50, 185.86),
            (250, 1055.45),
            (units - 400, 4.4217 * ( units - 400 )) 
        ]

        for limit, fee in rates:
            if calcUnits <= limit:
                baseFee += calcUnits * ( fee / limit )
                break
            else:
                baseFee += fee
                calcUnits -= limit

        print("Item                Price ")
        print("_ _ _ _ _ _ _ _ _ _ _ _ _ _")
        print(f"Base electricity  {baseFee:.2f} THB")
        elecBill(baseFee)

    def elecBill(baseFee):
        """ Calculate total electricity cost with service fee, FT, and VAT """

        service = 8.19
        ft = 39.72
        vat = 0.07

        base = baseFee + service
        vatFee = ( base + ft ) * vat
        total = base + ft + vatFee

        print(f"Service fee       {service:.2f} THB")
        print(f"FT charge         {ft:.2f} THB")
        print(f"VAT.              {vatFee:.2f} THB")
        print("_ _ _ _ _ _ _ _ _ _ _ _ _ _")
        print(f"Total             {total:.2f} THB")
        print("_ _ _ _ _ _ _ _ _ _ _ _ _ _")
        print("")
        print("        @PowerPay")

    baseElec()

PowerPay()